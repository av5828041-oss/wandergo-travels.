# WanderGo Travels — GitHub Pages Website

A responsive static website made with HTML, CSS and JavaScript. It can be hosted for free using GitHub Pages.

## Publish it on GitHub Pages

1. Sign in at https://github.com/ and create a **new repository**.
2. Name it `wandergo-travels` (or another name you like). For the simplest setup, make it **Public**.
3. Upload `index.html`, `style.css`, `script.js`, and `README.md` from this folder to the repository's root (top level).
4. In your repository, open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Choose branch **main** and folder **/(root)**, then click **Save**.
7. Wait a few minutes. The Pages screen will show your live website URL.

## Connect the enquiry form to WhatsApp

1. Open `script.js` in GitHub and click the pencil/edit icon.
2. Find `const WHATSAPP_NUMBER = "";`
3. Replace the empty string with your WhatsApp number including country code, digits only. Example format for India: `919876543210`.
4. Save/commit the change. The form will then open WhatsApp with the visitor's enquiry prefilled.

Until you add a real number, the form copies the enquiry text instead of sending it. Do not publish fake contact details.

## Edit your website

- `index.html`: text, destinations, services and sections
- `style.css`: colours, fonts, spacing and responsive layout
- `script.js`: mobile menu and enquiry form behaviour

## Notes

- The website is static and does not require a server or build process.
- Destination photography loads from Unsplash, so those images need an internet connection.
- Package cards are examples, not confirmed offers. Add verified prices and inclusions only when you have them.
- Add your genuine contact details and social links before sharing the website with customers.
