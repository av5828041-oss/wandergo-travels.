// WanderGo Travels — GitHub Pages-ready interactions
// To send enquiries to WhatsApp, replace the empty number below with your country code + number.
// Example format: "919876543210" (digits only). Do not include +, spaces, or hyphens.
const WHATSAPP_NUMBER = "";

const menuToggle = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");

menuToggle?.addEventListener("click", () => {
  const isOpen = nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
  menuToggle.textContent = isOpen ? "✕" : "☰";
});

nav?.querySelectorAll("a").forEach(link => {
  link.addEventListener("click", () => {
    nav.classList.remove("open");
    menuToggle?.setAttribute("aria-expanded", "false");
    if (menuToggle) menuToggle.textContent = "☰";
  });
});

document.getElementById("year").textContent = new Date().getFullYear();

document.getElementById("enquiry-form")?.addEventListener("submit", event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const message = [
    "Hello WanderGo Travels! I'd like to plan a trip.",
    `Name: ${form.get("name")}`,
    `Phone: ${form.get("phone")}`,
    `Destination: ${form.get("destination")}`,
    `Travel dates: ${form.get("dates") || "Not decided"}`,
    `Travellers: ${form.get("travellers")}`,
    `Message: ${form.get("message") || "No additional details"}`
  ].join("\n");

  if (WHATSAPP_NUMBER.trim()) {
    window.open(`https://wa.me/${WHATSAPP_NUMBER.trim()}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
  } else {
    const textArea = document.createElement("textarea");
    textArea.value = message;
    textArea.setAttribute("readonly", "");
    textArea.style.position = "fixed";
    textArea.style.opacity = "0";
    document.body.appendChild(textArea);
    textArea.select();
    const copied = document.execCommand("copy");
    textArea.remove();
    alert(copied
      ? "Your enquiry text has been copied. Add your WhatsApp number in script.js, then submit again to send it directly."
      : "Please copy your enquiry details and send them to your travel agency contact.");
  }
});
